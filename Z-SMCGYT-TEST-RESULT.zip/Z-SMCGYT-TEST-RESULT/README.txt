This folder contains the original data of the paper and the performance profile graph.

Please refer to the paper 
<< A Class of New Subspace Minimization Conjugate Gradient Methods with Sufficient Descent Property for Unconstrained Optimization >>

